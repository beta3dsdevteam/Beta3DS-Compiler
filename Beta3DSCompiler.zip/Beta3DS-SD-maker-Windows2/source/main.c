// Beta3DS SD card maker for Windows.
//
// Give it your b1.7.3.jar, your resources folder and (optionally) dspfirm.cdc, and pick
// the SD card. It writes the 3ds folder Beta3DS needs:
//   3ds/beta3ds.3dsx                    the game (built into this app)
//   3ds/beta3ds/b1.7.3.jar              your jar (a copy)
//   3ds/beta3ds/resources/...           the sounds and music the game reads
//   3ds/dspfirm.cdc                     the DSP firmware, for audio (a copy, if you choose it)
// No Minecraft file is in this app: everything from Minecraft is copied from your own files.
#include "win32.h"

// The game: GAME_3DSX[] and GAME_3DSX_LEN, made from Beta3DS's beta3ds.3dsx.
#include "game_3dsx.inc"

#ifndef HOST_TEST
_Static_assert(sizeof(WIN32_FIND_DATAW) == 592, "find data layout");
_Static_assert(sizeof(WNDCLASSEXW) == 80, "window class layout");
_Static_assert(sizeof(MSG) == 48, "message layout");
_Static_assert(sizeof(OPENFILENAMEW) == 152, "open file layout");
_Static_assert(sizeof(BROWSEINFOW) == 64, "browse layout");
#endif

#define PATHCAP 1200          // wide characters per path buffer (heap allocated)
#define MAX_TREE_DEPTH 8

enum {
	ID_ED_JAR = 101, ID_ED_RES, ID_ED_DSP, ID_ED_OUT,
	ID_BR_JAR = 111, ID_BR_RES, ID_BR_DSP, ID_BR_OUT,
	ID_GO = 120, ID_LOG = 130,
};

static HINSTANCE g_inst;
static HWND g_hwnd;
static HWND g_ed[4];        // jar, resources, dspfirm, SD card
static HWND g_log;
static HGDIOBJ g_font;
static DWORD g_copied, g_errors;

static const wchar_t JAR_FILTER[] = L"Minecraft jar (*.jar)\0*.jar\0All files\0*.*\0\0";
static const wchar_t ANY_FILTER[] = L"All files\0*.*\0\0";

// ---------- memory and strings (no C runtime is linked) ----------

void* memset(void* d, int c, size_t n)
{
	unsigned char* p = d;
	while (n--) *p++ = (unsigned char)c;
	return d;
}

void* memcpy(void* d, const void* s, size_t n)
{
	unsigned char* p = d;
	const unsigned char* q = s;
	while (n--) *p++ = *q++;
	return d;
}

void* memmove(void* d, const void* s, size_t n)
{
	unsigned char* p = d;
	const unsigned char* q = s;
	if (p < q) { while (n--) *p++ = *q++; }
	else { p += n; q += n; while (n--) *--p = *--q; }
	return d;
}

int memcmp(const void* a, const void* b, size_t n)
{
	const unsigned char* p = a;
	const unsigned char* q = b;
	for (size_t i = 0; i < n; i++)
		if (p[i] != q[i]) return p[i] < q[i] ? -1 : 1;
	return 0;
}

static void* mem_alloc(size_t n) { return HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, n); }
static void mem_free(void* p) { if (p) HeapFree(GetProcessHeap(), 0, p); }

static size_t wlen(const wchar_t* s)
{
	size_t n = 0;
	while (s[n]) n++;
	return n;
}

static void wcat(wchar_t* dst, size_t cap, const wchar_t* s)
{
	size_t n = wlen(dst);
	while (*s && n + 1 < cap) dst[n++] = *s++;
	dst[n] = 0;
}

static void wcpy(wchar_t* dst, size_t cap, const wchar_t* s)
{
	dst[0] = 0;
	wcat(dst, cap, s);
}

// dst = a + "\" + b (a single backslash between them)
static void join(wchar_t* dst, size_t cap, const wchar_t* a, const wchar_t* b)
{
	wcpy(dst, cap, a);
	size_t n = wlen(a);
	if (n && a[n - 1] != L'\\') wcat(dst, cap, L"\\");
	wcat(dst, cap, b);
}

static void wnum(wchar_t* s, size_t cap, DWORD v)
{
	wchar_t tmp[16];
	int n = 0;
	do { tmp[n++] = (wchar_t)(L'0' + v % 10); v /= 10; } while (v && n < 15);
	wchar_t out[16];
	int k = 0;
	while (n) out[k++] = tmp[--n];
	out[k] = 0;
	wcat(s, cap, out);
}

// ---------- the log box ----------

static void log_text(const wchar_t* s)
{
	int n = GetWindowTextLengthW(g_log);
	SendMessageW(g_log, EM_SETSEL, (WPARAM)n, (LPARAM)n);
	SendMessageW(g_log, EM_REPLACESEL, 0, (LPARAM)s);
	UpdateWindow(g_log);
}

static void log_line(const wchar_t* s)
{
	log_text(s);
	log_text(L"\r\n");
}

// "prefix N suffix" on one line
static void log_num(const wchar_t* prefix, DWORD v, const wchar_t* suffix)
{
	wchar_t* line = mem_alloc(PATHCAP * sizeof(wchar_t));
	if (!line) return;
	wcpy(line, PATHCAP, prefix);
	wnum(line, PATHCAP, v);
	wcat(line, PATHCAP, suffix);
	log_line(line);
	mem_free(line);
}

// ---------- files and folders ----------

static int is_dir(const wchar_t* p)
{
	DWORD a = GetFileAttributesW(p);
	return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

static int is_file(const wchar_t* p)
{
	DWORD a = GetFileAttributesW(p);
	return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

static int ensure_dir(const wchar_t* p)
{
	if (CreateDirectoryW(p, NULL)) return 1;
	return GetLastError() == ERROR_ALREADY_EXISTS;
}

// Makes base\rel, one folder at a time. rel uses backslashes, e.g. L"newsound\\mob".
static int ensure_chain(const wchar_t* base, const wchar_t* rel)
{
	wchar_t* cur = mem_alloc(PATHCAP * sizeof(wchar_t));
	if (!cur) return 0;
	wcpy(cur, PATHCAP, base);
	int ok = 1;
	const wchar_t* p = rel;
	while (*p && ok) {
		const wchar_t* e = p;
		while (*e && *e != L'\\') e++;
		if (e > p) {
			wcat(cur, PATHCAP, L"\\");
			for (const wchar_t* q = p; q < e; q++) {
				wchar_t c[2] = { *q, 0 };
				wcat(cur, PATHCAP, c);
			}
			ok = ensure_dir(cur);
		}
		p = *e ? e + 1 : e;
	}
	mem_free(cur);
	return ok;
}

// Reads a whole file into memory. Free the buffer with mem_free.
static int read_whole(const wchar_t* path, unsigned char** out, DWORD* outLen)
{
	HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (f == INVALID_HANDLE_VALUE) return 0;
	DWORD size = GetFileSize(f, NULL);
	if (size == 0xFFFFFFFFUL || size == 0 || size > 128UL * 1024 * 1024) { CloseHandle(f); return 0; }
	unsigned char* buf = mem_alloc(size);
	DWORD got = 0;
	int ok = buf && ReadFile(f, buf, size, &got, NULL) && got == size;
	CloseHandle(f);
	if (!ok) { mem_free(buf); return 0; }
	*out = buf;
	*outLen = size;
	return 1;
}

static int write_bytes(const wchar_t* path, const void* data, DWORD len)
{
	HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (f == INVALID_HANDLE_VALUE) return 0;
	DWORD done = 0;
	int ok = 1;
	while (ok && done < len) {
		DWORD chunk = len - done;
		if (chunk > (1UL << 20)) chunk = 1UL << 20;
		DWORD w = 0;
		ok = WriteFile(f, (const unsigned char*)data + done, chunk, &w, NULL) && w > 0;
		done += w;
	}
	CloseHandle(f);
	return ok && done == len;
}

// Copies a folder tree, file by file. src and dst must exist.
static void copy_tree(const wchar_t* src, const wchar_t* dst, int depth)
{
	wchar_t* pat = mem_alloc(PATHCAP * sizeof(wchar_t));
	if (!pat) return;
	join(pat, PATHCAP, src, L"*");
	WIN32_FIND_DATAW fd;
	HANDLE h = FindFirstFileW(pat, &fd);
	if (h != INVALID_HANDLE_VALUE) {
		do {
			const wchar_t* nm = fd.cFileName;
			if (nm[0] == L'.' && (nm[1] == 0 || (nm[1] == L'.' && nm[2] == 0))) continue;
			wchar_t* s = mem_alloc(PATHCAP * sizeof(wchar_t));
			wchar_t* d = mem_alloc(PATHCAP * sizeof(wchar_t));
			if (s && d) {
				join(s, PATHCAP, src, nm);
				join(d, PATHCAP, dst, nm);
				if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
					if (depth < MAX_TREE_DEPTH && ensure_dir(d)) copy_tree(s, d, depth + 1);
				} else if (CopyFileW(s, d, FALSE)) {
					g_copied++;
				} else {
					g_errors++;
				}
			}
			mem_free(s);
			mem_free(d);
		} while (FindNextFileW(h, &fd));
		FindClose(h);
	}
	mem_free(pat);
}

// ---------- the jar (a zip file): checks the names of its files without unpacking them ----------

static DWORD le32(const unsigned char* p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((DWORD)p[3] << 24); }
static DWORD le16(const unsigned char* p) { return p[0] | (p[1] << 8); }

// 1 if the zip has a file called want, 0 if not, -1 if the bytes aren't a zip.
static int jar_has(const unsigned char* b, DWORD n, const char* want)
{
	if (n < 22) return -1;
	DWORD lo = n > 65557 ? n - 65557 : 0;
	DWORD eocd = 0;
	int found = 0;
	for (DWORD i = n - 22;; i--) {
		if (le32(b + i) == 0x06054b50) { eocd = i; found = 1; break; }
		if (i == lo) break;
	}
	if (!found) return -1;
	DWORD count = le16(b + eocd + 10);
	DWORD p = le32(b + eocd + 16);
	size_t wl = 0;
	while (want[wl]) wl++;
	for (DWORD k = 0; k < count; k++) {
		if (p + 46 > n || le32(b + p) != 0x02014b50) return -1;
		DWORD nl = le16(b + p + 28), xl = le16(b + p + 30), cl = le16(b + p + 32);
		if (p + 46 + nl > n) return -1;
		if (nl == wl && memcmp(b + p + 46, want, wl) == 0) return 1;
		p += 46 + nl + xl + cl;
	}
	return 0;
}

// ---------- the dialogs ----------

static int browse_file(HWND owner, const wchar_t* filter, wchar_t* out, DWORD cap)
{
	OPENFILENAMEW ofn;
	memset(&ofn, 0, sizeof ofn);
	ofn.lStructSize = sizeof ofn;
	ofn.hwndOwner = owner;
	ofn.lpstrFilter = filter;
	ofn.lpstrFile = out;
	ofn.nMaxFile = cap;
	ofn.Flags = OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
	return GetOpenFileNameW(&ofn) ? 1 : 0;
}

static int browse_folder(HWND owner, wchar_t* out, DWORD cap)
{
	wchar_t display[MAX_PATH];
	wchar_t path[MAX_PATH];
	BROWSEINFOW bi;
	memset(&bi, 0, sizeof bi);
	bi.hwndOwner = owner;
	bi.pszDisplayName = display;
	bi.lpszTitle = L"Choose your SD card (the folder with 3ds in it, or the one to put it in)";
	bi.ulFlags = BIF_RETURNONLYFSDIRS;
	LPITEMIDLIST pidl = SHBrowseForFolderW(&bi);
	if (!pidl) return 0;
	int ok = SHGetPathFromIDListW(pidl, path);
	CoTaskMemFree(pidl);
	if (ok) wcpy(out, cap, path);
	return ok ? 1 : 0;
}

// ---------- making the folder ----------

static void make_card(void)
{
	wchar_t* jar = mem_alloc(PATHCAP * sizeof(wchar_t));
	wchar_t* res = mem_alloc(PATHCAP * sizeof(wchar_t));
	wchar_t* dsp = mem_alloc(PATHCAP * sizeof(wchar_t));
	wchar_t* out = mem_alloc(PATHCAP * sizeof(wchar_t));
	wchar_t* dir3 = mem_alloc(PATHCAP * sizeof(wchar_t));
	wchar_t* dirBeta = mem_alloc(PATHCAP * sizeof(wchar_t));
	wchar_t* dst = mem_alloc(PATHCAP * sizeof(wchar_t));
	wchar_t* src = mem_alloc(PATHCAP * sizeof(wchar_t));
	if (!jar || !res || !dsp || !out || !dir3 || !dirBeta || !dst || !src) {
		log_line(L"Not enough memory.");
		goto done;
	}
	GetWindowTextW(g_ed[0], jar, PATHCAP);
	GetWindowTextW(g_ed[1], res, PATHCAP);
	GetWindowTextW(g_ed[2], dsp, PATHCAP);
	GetWindowTextW(g_ed[3], out, PATHCAP);
	g_copied = 0;
	g_errors = 0;

	if (!out[0] || !is_dir(out)) {
		log_line(L"Choose your SD card first (the folder that holds, or will hold, the 3ds folder).");
		goto done;
	}
	log_line(L"");
	log_line(L"Making the 3DS files...");

	join(dir3, PATHCAP, out, L"3ds");
	join(dirBeta, PATHCAP, dir3, L"beta3ds");
	if (!ensure_dir(dir3) || !ensure_dir(dirBeta)) {
		log_line(L"Couldn't make the 3ds and beta3ds folders on that card. Is it read-only?");
		goto done;
	}

	// 1. the game
	join(dst, PATHCAP, dir3, L"beta3ds.3dsx");
	if (write_bytes(dst, GAME_3DSX, GAME_3DSX_LEN)) {
		g_copied++;
		log_line(L"Wrote 3ds\\beta3ds.3dsx (the game).");
	} else {
		g_errors++;
		log_num(L"Couldn't write beta3ds.3dsx, error ", GetLastError(), L".");
	}

	// 2. the jar
	if (jar[0]) {
		unsigned char* buf = NULL;
		DWORD len = 0;
		if (!read_whole(jar, &buf, &len)) {
			g_errors++;
			log_line(L"Couldn't read the jar. Check the path to b1.7.3.jar.");
		} else {
			int isZip = jar_has(buf, len, "terrain.png");
			if (isZip < 0) {
				g_errors++;
				log_line(L"That file isn't a jar (zip). It wasn't copied.");
			} else {
				static const char* const WANT[] = {
					"terrain.png", "gui/items.png", "title/mclogo.png", "misc/grasscolor.png",
					"misc/foliagecolor.png", "mob/char.png", "lang/en_US.lang",
				};
				for (int i = 0; i < 7; i++) {
					if (jar_has(buf, len, WANT[i]) == 0) {
						wchar_t line[128];
						wcpy(line, 128, L"Your jar has no ");
						for (const char* c = WANT[i]; *c && wlen(line) < 100; c++) {
							wchar_t w[2] = { (wchar_t)*c, 0 };
							wcat(line, 128, w);
						}
						wcat(line, 128, L": the game uses its built-in version of that.");
						log_line(line);
					}
				}
				if (isZip >= 0) {
					join(dst, PATHCAP, dirBeta, L"b1.7.3.jar");
					if (CopyFileW(jar, dst, FALSE)) {
						g_copied++;
						log_line(L"Copied your jar to 3ds\\beta3ds\\b1.7.3.jar.");
					} else {
						g_errors++;
						log_num(L"Couldn't copy the jar, error ", GetLastError(), L".");
					}
				}
			}
		}
		mem_free(buf);
	} else {
		log_line(L"No jar chosen: the game uses its built-in textures.");
	}

	// 3. sounds and music from the resources folder
	if (res[0]) {
		if (!is_dir(res)) {
			g_errors++;
			log_line(L"The resources folder doesn't exist. Nothing was copied from it.");
		} else {
			static const wchar_t* const SUBS[] = {
				L"newsound\\step", L"newsound\\random", L"newsound\\ambient\\cave", L"newsound\\mob",
				L"music", L"newmusic", L"streaming",
			};
			wchar_t* dirRes = mem_alloc(PATHCAP * sizeof(wchar_t));
			if (dirRes && ensure_chain(dirBeta, L"resources")) {
				join(dirRes, PATHCAP, dirBeta, L"resources");
				int found = 0;
				for (int i = 0; i < 7; i++) {
					join(src, PATHCAP, res, SUBS[i]);
					if (!is_dir(src)) continue;
					found++;
					if (!ensure_chain(dirRes, SUBS[i])) { g_errors++; continue; }
					join(dst, PATHCAP, dirRes, SUBS[i]);
					DWORD mine = g_copied;
					copy_tree(src, dst, 0);
					wchar_t line[200];
					wcpy(line, 200, L"Copied resources\\");
					wcat(line, 200, SUBS[i]);
					wcat(line, 200, L": ");
					wchar_t n[16];
					n[0] = 0;
					wnum(n, 16, g_copied - mine);
					wcat(line, 200, n);
					wcat(line, 200, L" files.");
					log_line(line);
				}
				if (!found) log_line(L"That folder has no newsound, music, newmusic or streaming folders: it isn't the resources folder.");
			} else {
				g_errors++;
				log_line(L"Couldn't make the resources folder on that card.");
			}
			mem_free(dirRes);
		}
	} else {
		log_line(L"No resources folder chosen: the game uses its own sounds and generates the music.");
	}

	// 4. DSP firmware (audio)
	if (dsp[0]) {
		join(dst, PATHCAP, dir3, L"dspfirm.cdc");
		if (is_file(dsp) && CopyFileW(dsp, dst, FALSE)) {
			g_copied++;
			log_line(L"Copied dspfirm.cdc to 3ds\\dspfirm.cdc (for sound).");
		} else {
			g_errors++;
			log_line(L"Couldn't copy dspfirm.cdc. Check the path.");
		}
	}

	log_line(L"");
	log_num(L"Done: ", g_copied, L" file(s) written.");
	if (g_errors) log_num(L"", g_errors, L" problem(s): see above.");
	log_line(L"Eject the card, then start Beta3DS from the Homebrew Launcher (3ds\\beta3ds.3dsx).");
	MessageBoxW(g_hwnd, g_errors ? L"Finished, with some problems. See the log." : L"The 3ds folder is ready on your SD card.",
	            L"Beta3DS SD card maker", MB_OK | MB_ICONINFORMATION);

done:
	mem_free(jar); mem_free(res); mem_free(dsp); mem_free(out);
	mem_free(dir3); mem_free(dirBeta); mem_free(dst); mem_free(src);
}

// ---------- the window ----------

static HWND make_child(const wchar_t* cls, const wchar_t* text, DWORD style, int x, int y, int w, int h, int id)
{
	HWND c = CreateWindowExW(0, cls, text, WS_CHILD | WS_VISIBLE | style, x, y, w, h, g_hwnd, (HMENU)(LONG_PTR)id, g_inst, NULL);
	if (c) SendMessageW(c, WM_SETFONT, (WPARAM)g_font, TRUE);
	return c;
}

static void make_row(int row, const wchar_t* label, int edId, int brId)
{
	int y = 46 + row * 36;
	make_child(L"STATIC", label, 0, 14, y + 4, 210, 20, 0);
	g_ed[edId - ID_ED_JAR] = make_child(L"EDIT", L"", WS_BORDER | WS_TABSTOP | ES_AUTOHSCROLL, 228, y, 270, 24, edId);
	make_child(L"BUTTON", L"Browse...", BS_PUSHBUTTON | WS_TABSTOP, 506, y, 72, 24, brId);
}

static LRESULT WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg) {
	case WM_COMMAND:
		if (((wp >> 16) & 0xFFFF) == BN_CLICKED) {
			switch (wp & 0xFFFF) {
			case ID_BR_JAR: {
				wchar_t* p = mem_alloc(PATHCAP * sizeof(wchar_t));
				if (p && browse_file(h, JAR_FILTER, p, PATHCAP)) SetWindowTextW(g_ed[0], p);
				mem_free(p);
				break;
			}
			case ID_BR_RES: {
				wchar_t* p = mem_alloc(PATHCAP * sizeof(wchar_t));
				if (p && browse_folder(h, p, PATHCAP)) SetWindowTextW(g_ed[1], p);
				mem_free(p);
				break;
			}
			case ID_BR_DSP: {
				wchar_t* p = mem_alloc(PATHCAP * sizeof(wchar_t));
				if (p && browse_file(h, ANY_FILTER, p, PATHCAP)) SetWindowTextW(g_ed[2], p);
				mem_free(p);
				break;
			}
			case ID_BR_OUT: {
				wchar_t* p = mem_alloc(PATHCAP * sizeof(wchar_t));
				if (p && browse_folder(h, p, PATHCAP)) SetWindowTextW(g_ed[3], p);
				mem_free(p);
				break;
			}
			case ID_GO:
				make_card();
				break;
			}
		}
		return 0;
	case WM_CLOSE:
		DestroyWindow(h);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProcW(h, msg, wp, lp);
}

void WinEntry(void)
{
	g_inst = GetModuleHandleW(NULL);
	g_font = GetStockObject(DEFAULT_GUI_FONT);

	WNDCLASSEXW wc;
	memset(&wc, 0, sizeof wc);
	wc.cbSize = sizeof wc;
	wc.lpfnWndProc = WndProc;
	wc.hInstance = g_inst;
	wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(LONG_PTR)(COLOR_BTNFACE + 1);
	wc.lpszClassName = L"Beta3DSSdMaker";
	RegisterClassExW(&wc);

	g_hwnd = CreateWindowExW(0, L"Beta3DSSdMaker", L"Beta3DS SD card maker", WS_OVERLAPPEDWINDOW,
	                         CW_USEDEFAULT, CW_USEDEFAULT, 606, 500, NULL, NULL, g_inst, NULL);
	if (!g_hwnd) ExitProcess(1);

	make_child(L"STATIC",
	           L"Makes the 3ds folder for Beta3DS. Your jar, sounds and music are copied from your own files.",
	           0, 14, 12, 560, 20, 0);
	make_row(0, L"Your b1.7.3.jar (for textures):", ID_ED_JAR, ID_BR_JAR);
	make_row(1, L"Resources folder (for sounds and music):", ID_ED_RES, ID_BR_RES);
	make_row(2, L"dspfirm.cdc (for sound, optional):", ID_ED_DSP, ID_BR_DSP);
	make_row(3, L"SD card (the folder to put 3ds in):", ID_ED_OUT, ID_BR_OUT);
	make_child(L"BUTTON", L"Make the 3ds folder", BS_DEFPUSHBUTTON | WS_TABSTOP, 14, 186, 230, 32, ID_GO);
	g_log = make_child(L"EDIT", L"",
	                   WS_BORDER | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY, 14, 232, 564, 220, ID_LOG);
	log_line(L"Choose the jar, the resources folder and your SD card, then press the button.");
	log_line(L"The game itself is built in. It needs dspfirm.cdc only for sound.");

	ShowWindow(g_hwnd, SW_SHOWDEFAULT);
	UpdateWindow(g_hwnd);

	MSG msg;
	while (GetMessageW(&msg, NULL, 0, 0) > 0) {
		TranslateMessage(&msg);
		DispatchMessageW(&msg);
	}
	ExitProcess(0);
}
