# Writes game_3dsx.inc from Beta3DS's beta3ds.3dsx, so the app can carry the game inside the .exe.
# usage: python3 make_game_inc.py "path/to/beta3ds.3dsx"
import sys
data = open(sys.argv[1], "rb").read()
rows = []
for i in range(0, len(data), 24):
    rows.append("\t" + ",".join("0x%02x" % b for b in data[i:i + 24]) + ",")
with open("game_3dsx.inc", "w") as f:
    f.write("/* beta3ds.3dsx, %d bytes */\nstatic const unsigned char GAME_3DSX[] = {\n%s\n};\n"
            "static const unsigned long GAME_3DSX_LEN = %d;\n" % (len(data), "\n".join(rows), len(data)))
print("wrote game_3dsx.inc (%d bytes)" % len(data))
