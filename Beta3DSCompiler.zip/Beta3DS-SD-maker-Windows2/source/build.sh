#!/bin/sh
# Builds Beta3DS-SD-maker.exe for Windows (64-bit) on Linux with clang and LLVM, no Windows SDK needed.
# Needs: clang, llvm-rc, lld-link and llvm-dlltool (LLVM 14 or newer), and the Beta3DS beta3ds.3dsx.
set -e
python3 make_game_inc.py "${1:-beta3ds.3dsx}"
for d in kernel32 user32 gdi32 comdlg32 shell32 ole32; do
  llvm-dlltool -m i386:x86-64 -d $d.def -l $d.lib
done
llvm-rc /FO app.res app.rc
clang --target=x86_64-pc-windows-msvc -O2 -Wall -Wextra -ffreestanding -fno-builtin \
      -fno-stack-protector -mno-stack-arg-probe -c main.c -o main.obj
lld-link /subsystem:windows /entry:WinEntry /nodefaultlib /machine:x64 /out:Beta3DS-SD-maker.exe \
      main.obj app.res kernel32.lib user32.lib gdi32.lib comdlg32.lib shell32.lib ole32.lib
echo "built Beta3DS-SD-maker.exe"
