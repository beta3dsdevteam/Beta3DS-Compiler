// The few Win32 types and functions this app uses, declared by hand so it can be built
// on Linux with clang and no Windows SDK. Struct sizes are checked in main.c.
#pragma once
#include <stddef.h>

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;
typedef long LONG;
typedef int BOOL;
typedef unsigned int UINT;
typedef int INT;
typedef unsigned long long UINT_PTR;
typedef long long LONG_PTR;
typedef UINT_PTR WPARAM;
typedef LONG_PTR LPARAM;
typedef LONG_PTR LRESULT;
typedef UINT_PTR SIZE_T;
typedef wchar_t WCHAR;
typedef const wchar_t* LPCWSTR;
typedef wchar_t* LPWSTR;
typedef void* LPVOID;
typedef const void* LPCVOID;
typedef DWORD* LPDWORD;
typedef void* HANDLE;
typedef HANDLE HWND;
typedef HANDLE HINSTANCE;
typedef HANDLE HMODULE;
typedef HANDLE HICON;
typedef HANDLE HCURSOR;
typedef HANDLE HBRUSH;
typedef HANDLE HMENU;
typedef HANDLE HGDIOBJ;
typedef HANDLE HFONT;
typedef HANDLE LPITEMIDLIST;
typedef HANDLE HHOOK;
typedef WORD ATOM;
typedef void* LPOVERLAPPED;
typedef LRESULT (*WNDPROC)(HWND, UINT, WPARAM, LPARAM);

#define TRUE 1
#define FALSE 0
#define MAX_PATH 260
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
#define INVALID_FILE_ATTRIBUTES ((DWORD)0xFFFFFFFF)
#define FILE_ATTRIBUTE_DIRECTORY 0x10
#define FILE_ATTRIBUTE_NORMAL 0x80
#define GENERIC_READ 0x80000000UL
#define GENERIC_WRITE 0x40000000UL
#define FILE_SHARE_READ 0x1
#define OPEN_EXISTING 3
#define CREATE_ALWAYS 2
#define ERROR_ALREADY_EXISTS 183

#define WS_OVERLAPPED 0x00000000UL
#define WS_OVERLAPPEDWINDOW 0x00CF0000UL
#define WS_CHILD 0x40000000UL
#define WS_VISIBLE 0x10000000UL
#define WS_BORDER 0x00800000UL
#define WS_VSCROLL 0x00200000UL
#define WS_TABSTOP 0x00010000UL
#define ES_MULTILINE 0x0004UL
#define ES_AUTOVSCROLL 0x0040UL
#define ES_AUTOHSCROLL 0x0080UL
#define ES_READONLY 0x0800UL
#define BS_PUSHBUTTON 0x00000000UL
#define BS_DEFPUSHBUTTON 0x00000001UL
#define CW_USEDEFAULT ((int)0x80000000)
#define COLOR_BTNFACE 15
#define SW_SHOWDEFAULT 10
#define IDC_ARROW ((LPCWSTR)(LONG_PTR)32512)
#define DEFAULT_GUI_FONT 17
#define MB_OK 0x0
#define MB_ICONINFORMATION 0x40
#define MB_ICONWARNING 0x30

#define WM_DESTROY 0x0002
#define WM_CLOSE 0x0010
#define WM_SETFONT 0x0030
#define WM_COMMAND 0x0111
#define WM_USER 0x0400
#define BN_CLICKED 0
#define EM_SETSEL 0x00B1
#define EM_REPLACESEL 0x00C2
#define WM_GETTEXTLENGTH 0x000E

#define OFN_HIDEREADONLY 0x00000004UL
#define OFN_PATHMUSTEXIST 0x00000800UL
#define OFN_FILEMUSTEXIST 0x00001000UL
#define BIF_RETURNONLYFSDIRS 0x00000001UL
#define BIF_NEWDIALOGSTYLE 0x00000040UL

#define HEAP_ZERO_MEMORY 0x00000008UL

typedef struct { LONG x; LONG y; } POINT;

typedef struct {
	DWORD dwLowDateTime;
	DWORD dwHighDateTime;
} FILETIME;

typedef struct {
	DWORD dwFileAttributes;
	FILETIME ftCreationTime;
	FILETIME ftLastAccessTime;
	FILETIME ftLastWriteTime;
	DWORD nFileSizeHigh;
	DWORD nFileSizeLow;
	DWORD dwReserved0;
	DWORD dwReserved1;
	WCHAR cFileName[260];
	WCHAR cAlternateFileName[14];
} WIN32_FIND_DATAW;

typedef struct {
	UINT cbSize;
	UINT style;
	WNDPROC lpfnWndProc;
	int cbClsExtra;
	int cbWndExtra;
	HINSTANCE hInstance;
	HICON hIcon;
	HCURSOR hCursor;
	HBRUSH hbrBackground;
	LPCWSTR lpszMenuName;
	LPCWSTR lpszClassName;
	HICON hIconSm;
} WNDCLASSEXW;

typedef struct {
	HWND hwnd;
	UINT message;
	WPARAM wParam;
	LPARAM lParam;
	DWORD time;
	POINT pt;
	DWORD lPrivate;
} MSG;

typedef struct {
	DWORD lStructSize;
	HWND hwndOwner;
	HINSTANCE hInstance;
	LPCWSTR lpstrFilter;
	LPWSTR lpstrCustomFilter;
	DWORD nMaxCustFilter;
	DWORD nFilterIndex;
	LPWSTR lpstrFile;
	DWORD nMaxFile;
	LPWSTR lpstrFileTitle;
	DWORD nMaxFileTitle;
	LPCWSTR lpstrInitialDir;
	LPCWSTR lpstrTitle;
	DWORD Flags;
	WORD nFileOffset;
	WORD nFileExtension;
	LPCWSTR lpstrDefExt;
	LPARAM lCustData;
	void* lpfnHook;
	LPCWSTR lpTemplateName;
	void* pvReserved;
	DWORD dwReserved;
	DWORD FlagsEx;
} OPENFILENAMEW;

typedef struct {
	HWND hwndOwner;
	LPITEMIDLIST pidlRoot;
	LPWSTR pszDisplayName;
	LPCWSTR lpszTitle;
	UINT ulFlags;
	void* lpfn;
	LPARAM lParam;
	int iImage;
} BROWSEINFOW;


// kernel32
__declspec(dllimport) HMODULE GetModuleHandleW(LPCWSTR);
__declspec(dllimport) HANDLE GetProcessHeap(void);
__declspec(dllimport) LPVOID HeapAlloc(HANDLE, DWORD, SIZE_T);
__declspec(dllimport) BOOL HeapFree(HANDLE, DWORD, LPVOID);
__declspec(dllimport) HANDLE CreateFileW(LPCWSTR, DWORD, DWORD, void*, DWORD, DWORD, HANDLE);
__declspec(dllimport) BOOL ReadFile(HANDLE, LPVOID, DWORD, LPDWORD, LPOVERLAPPED);
__declspec(dllimport) BOOL WriteFile(HANDLE, LPCVOID, DWORD, LPDWORD, LPOVERLAPPED);
__declspec(dllimport) BOOL CloseHandle(HANDLE);
__declspec(dllimport) DWORD GetFileSize(HANDLE, LPDWORD);
__declspec(dllimport) BOOL CreateDirectoryW(LPCWSTR, void*);
__declspec(dllimport) HANDLE FindFirstFileW(LPCWSTR, WIN32_FIND_DATAW*);
__declspec(dllimport) BOOL FindNextFileW(HANDLE, WIN32_FIND_DATAW*);
__declspec(dllimport) BOOL FindClose(HANDLE);
__declspec(dllimport) DWORD GetFileAttributesW(LPCWSTR);
__declspec(dllimport) BOOL CopyFileW(LPCWSTR, LPCWSTR, BOOL);
__declspec(dllimport) DWORD GetLastError(void);
__declspec(dllimport) void ExitProcess(UINT);

// user32
__declspec(dllimport) ATOM RegisterClassExW(const WNDCLASSEXW*);
__declspec(dllimport) HWND CreateWindowExW(DWORD, LPCWSTR, LPCWSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);
__declspec(dllimport) LRESULT DefWindowProcW(HWND, UINT, WPARAM, LPARAM);
__declspec(dllimport) BOOL ShowWindow(HWND, int);
__declspec(dllimport) BOOL UpdateWindow(HWND);
__declspec(dllimport) int GetMessageW(MSG*, HWND, UINT, UINT);
__declspec(dllimport) BOOL TranslateMessage(const MSG*);
__declspec(dllimport) LRESULT DispatchMessageW(const MSG*);
__declspec(dllimport) void PostQuitMessage(int);
__declspec(dllimport) LRESULT SendMessageW(HWND, UINT, WPARAM, LPARAM);
__declspec(dllimport) BOOL SetWindowTextW(HWND, LPCWSTR);
__declspec(dllimport) int GetWindowTextW(HWND, LPWSTR, int);
__declspec(dllimport) int GetWindowTextLengthW(HWND);
__declspec(dllimport) BOOL DestroyWindow(HWND);
__declspec(dllimport) int MessageBoxW(HWND, LPCWSTR, LPCWSTR, UINT);
__declspec(dllimport) HCURSOR LoadCursorW(HINSTANCE, LPCWSTR);

// gdi32
__declspec(dllimport) HGDIOBJ GetStockObject(int);

// comdlg32
__declspec(dllimport) BOOL GetOpenFileNameW(OPENFILENAMEW*);

// shell32 and ole32
__declspec(dllimport) LPITEMIDLIST SHBrowseForFolderW(BROWSEINFOW*);
__declspec(dllimport) BOOL SHGetPathFromIDListW(LPITEMIDLIST, LPWSTR);
__declspec(dllimport) void CoTaskMemFree(LPVOID);
